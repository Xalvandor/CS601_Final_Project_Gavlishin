# CS601_Final_Project_Gavlishin
I created this portfolio website for the CS 601 term project at BU.
It uses HTML, CSS, and Javascript (no frameworks).

It features two react components to display the header and the footer.
The header has a navigation menu that can be toggled on and off.
The footer includes my logo, the year and name of the project,
and thumbnail links to my GitHub and my YouTube channel.
I decided to use a no build approach for these components since the whole site is not built using React.

The information on the about page is dynamically loaded from a JSON file using the fetch API,
and the DOM is updated with JS.

The resume page displays my resume using an object tag in the HTML.
Using html, I added a download link. With JS, I added an event listener which updates the DOM to show
a thank you message when downloaded. I also added button to show and hide the document with JS.

The projects page was adapted from assignment 3.
It highlights some of the CS projects I have worked on at BU.
It doesn't have any JS apart from the header and footer components.

For the music page, I created a playlist of a few videos from my YouTube channel.
The information is fetched from a JSON file and the playlist is dynamically created
and updated to the DOM using JS.
With each button click on the playlist, the DOM updates to feature the chosen video.

The contact page has a form for sending a message.
It includes input fields for first name, last name, email, and message.
It validates each field. First and last name only allow alpha characters.
The email field uses regex to check for the correct format. The message field cannot be left blank.
The DOM updates with an error message to the form if a field is entered incorrectly.
If everything is correct, the form is hidden and a success message is displayed.

For the CSS, I used a yellow, green, and blue color scheme throughout with similar styling for containers,
buttons, font, etc. on each page.
I have made the layout responsive to any screen size by using CSS grid and flexbox, a few media queries,
and a meta html tag to adjust the viewport.
I tested its responsiveness using responsive design mode in browser and on my own phone.

For the HTML, I included semantic elements whenever possible, either directly in the html or dynamically with JS.
I have made use of div elements for styling purposes.
All img elements have an alt attribute and height and width attributes in their CSS.
Additionally, I included meta and link tags on each page to include an icon on each tab,
and a link preview image when sharing on different platforms.

All html, css, and json was validated. The only error that popped up was for
including a no script tag in each html page.
Despite the error, this is necessary for situations when a user has JS disabled.

The site is hosted on GitHub pages. I tested it Firefox, Chrome, and Safari (mobile only).
Everything worked as intended and no errors popped up, except on Firefox when on the music page.
This CORS error is part of Firefox's tracking protection triggered by the YouTube videos,
and it does not come up on Chrome.
